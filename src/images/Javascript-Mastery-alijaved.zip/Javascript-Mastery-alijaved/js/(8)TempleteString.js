// templete string
let firstname = "aliJaved";
let age = 22;

// for example my age is ali my age is 22
let aboutus = `my name is ${firstname} my age is ${age}`;
console.log("aboutus", aboutus)
