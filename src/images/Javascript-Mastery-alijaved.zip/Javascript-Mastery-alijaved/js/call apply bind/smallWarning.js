
function myfunc() {
    console.log("sss")
}
myfunc.call()

const user1 = {
    name: "ali",
    age: "20",
    about(hobbhy, musician) {
        console.log(this.name, this.age, hobbhy, musician)
    }

}
const user2 = {
    name: "javed",
    age: "22",
}
// agar kisi variable object ka refrence bina call kre store krenge undefined aye ga! 
const hy = user1.about
console.log(hy())
// agar kisi variable object ka refrence bina call kre store krenge undefined aye ga! 
const Hy = user1.about.bind(user2)
console.log("he", Hy())

