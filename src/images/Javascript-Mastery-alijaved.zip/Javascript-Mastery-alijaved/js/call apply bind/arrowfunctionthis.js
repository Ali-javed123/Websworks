
const user1 = {
    name: "ali",
    age: "20",
    about: () => {
        console.log(this)
    }

}
// arrow function ka this 1 level upar hota h aur arrow funtion ke this ko aap badal nahe sakte
// arrow funtion ka this apne surrounding se 1 level upper se leta h window object hota h
user1.about(user1)
