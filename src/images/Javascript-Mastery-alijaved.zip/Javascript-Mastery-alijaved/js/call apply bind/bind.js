
function myfunc() {
    console.log("sss")
}
myfunc.call()

const user1 = {
    name: "ali",
    age: "20",
    about(hobbhy, musician) {
        console.log(this.name, this.age, hobbhy, musician)
    }

}
const user2 = {
    name: "javed",
    age: "22",
}
// agar mujhe user 1 about function ko use krna h aur about ka this user 2 krna h to
const myFunc = user1.about.bind(user2, "gittar", "hello")
// bind humein aik function return krta h
myFunc()
