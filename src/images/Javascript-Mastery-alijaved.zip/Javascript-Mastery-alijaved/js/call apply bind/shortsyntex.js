const user1 = {
    name: "ali",
    age: "20",
    about() {
        console.log(this.name, this.age)
    }

}
user1.about()

