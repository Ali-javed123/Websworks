let day =3
switch (day) {
    case 1:
        console.log("case one")
        break;
        case 2:
            console.log("case two")
            break;
            case 3:
                console.log("case three")
                break;
                case 4:
                    console.log("case four")
                    break;
                    case 5:
                    console.log("case fifth")
                    break;

    default:
        console.log("invalid")
        break;
}