// block scope vs function scope

// let and const block scope and var laxical scope
const myApp = () => {
    if (true) {
        let firstname = "ali";
        console.log("FirstName", firstname)
    }
    if (true) {
        let firstName = "AliJ"
        console.log("firstName", firstName)
    }

    if (true) {
        var SecondName = "AliJ"
        console.log("SecondName", SecondName)
    }
    console.log("SecondName", SecondName)


}
myApp()
// var is function scope
