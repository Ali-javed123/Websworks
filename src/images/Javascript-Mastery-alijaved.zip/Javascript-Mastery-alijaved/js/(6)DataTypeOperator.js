// typeof operator 

// data types (primitive data types)
// string "harhit"
// number 2, 4, 5.6 
// booleans 
// undefined
// null 
// BigInt
// Symbol

// use typeof
let age=20;
let firstName="ALijaved";
console.log(typeof (age +""))
// number convert into String

// first method
age =age +"";
console.log(typeof age)
// second method
let Age=5;
Age=String(Age)

console.log("seond method",typeof Age)
// number convert into String

// string convert into number

age = +age ;
console.log(typeof age)
// second method
let Ages="5";
Ages=Number(Ages)

console.log("seond method",typeof Ages)

// string convert into number

// type of undefined
// let or var ke case me variable undefined chor sakte hein but constant ke case me nahe
let username 
// this is undefined
console.log(typeof username)
username="ALijaved";
console.log(typeof username)
// constant undefined nahe chore sakte
//  const secndnames;
//  console.log(secndnames)

// type of null
let myvar=null
console.log("myvar", myvar, typeof myvar )
myvar="ali"
console.log("myvar", myvar, typeof myvar )
// type of null

// type of bigint
// write BigInt first type
let mynum=BigInt(12);
// write BigInt first type
let mynums=12n

console.log("mynum",mynum+mynums)
console.log("maximum store number",Number.MAX_SAFE_INTEGER)
// type of bigint


// boolean & comperisson operator
// booleans 
// true & false
let num1=7;
let num2=7;
console.log(num1>!num2);
console.log(num1>num2);
console.log(num1>=num1);

// == vs ===

let num3=7;
let num4="7";
console.log("== vs ===")
console.log(num3==num4)
console.log(num3===num4)
 
// != vs !==
let num5=7;
let num6='7';
console.log("num3 != num4",num5 != num6)

// boolean & comperisson operator


// truethy or falsy value
// flasy value
// 0 
// undefined
// false 
// null

