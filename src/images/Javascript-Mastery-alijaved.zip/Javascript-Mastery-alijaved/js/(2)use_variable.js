"use Strick";

var firstName = "Ali";
console.log(firstName)
firstName = "AliJaved";
console.log(firstName)
var secndnames = "ali";
console.log("secnd", secndnames)
var vale1 = 2;
console.log(2 ** 4)
// you can use only dollor underscrore symbal
// first_name (valid)

// _firstname(valid)
// first$name (valid)
var first$Name = "aliJaved";
console.log("first$Name", first$Name);
// $firstname (valid)
var $firstNames = "aliJaved";
console.log("$firstNames", $firstNames);
//  you cannot use space
var secondNames = "ALiJAved";
// camel case writing
console.log("secondNames", secondNames);

var second_Names = "ALiJAved";
// snake case writing
console.log("ALiJAved", second_Names);
// convention
// start small letter and use camelcase
var username = "AliJaved";
// you can use small letter
console.log("username", username)
// you can use camel case or snake case letter 
var userNames = "aliJaved";
console.log("Usernames", userNames)

// -firstname(valid)
// first_name(valid)

// you cannot use space
// firstName(valid)
// first Name(invalid)

// you can use cannot use valiable first character for number 
// 1firstName(invalid)
// firstName1(valid)
