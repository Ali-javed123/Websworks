// declear contant
const pi=3.41;
console.log("pi",pi)
// cannot change constant
