// intro to arrays
// refrence type
// how to create arrays

// ordered collection of item
let number=[1,2,3,4,5,6]
let fruits=["apple","mango","banana","graps"];
let obj={}
let mixed=[123,"string",undefined,null,true,false];
console.log(fruits[1])
console.log(fruits)
console.log(mixed)
console.log(number)
// change fruit array function
fruits[1]="Mango";
fruits[2]="Pineapple";
console.log(fruits)

// checking arrays
console.log(typeof fruits)
console.log( Array.isArray(fruits))
// checking object
console.log(typeof obj)
console.log(Array.isArray(obj))

