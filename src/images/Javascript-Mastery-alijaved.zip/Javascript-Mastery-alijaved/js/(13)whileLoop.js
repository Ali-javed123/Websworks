let i=0;
while(i<=10){
    console.log("i",i)
    i++
}
console.log(`current vlaue of i is ${i}`)

console.log("while loop sum total number")
let num=100;
let total=0;
let e=0;

while(e<=100){
    total=total+e
    e++
    console.log(total)
}

// math formula first and natural number
// console.log("first and natural number")
let Total=(num*(num+1))/2
console.log("Total",Total)