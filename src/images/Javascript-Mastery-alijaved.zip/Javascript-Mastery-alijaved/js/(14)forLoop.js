// intro to for loop
// print 0 to 9 number
// initilize let for loop block one type
let i;
for(i=0;i<=10;i++){
    console.log("i",i)
    // for loop defined variable let does not exit another block but intialize variable let upperside and for exit another block
     // for loop defined variable var exit another block and for exit another block
}
console.log("value of i is",i)
// initilize let for loop block one type


// initilize let for loop block second type

let e=0;
for(;e<=10;e++){
    console.log("e",e)
    // for loop defined variable let does not exit another block but intialize variable let upperside and for exit another block
     // for loop defined variable var exit another block and for exit another block
}
console.log("value of e is",e)
// initilize let for loop block second type

for(var a=0;a<=10;a++){
    console.log("a",a)
    // for loop defined variable let does not exit another block but intialize variable let upperside and for exit another block
     // for loop defined variable var exit for loop another block 
}
console.log("value of a is",a)



// example of for loop

let total=0
let num =10;
let b;
for (b=1;b<=10;b++)
total=total+b
console.log("value of total is ", total)