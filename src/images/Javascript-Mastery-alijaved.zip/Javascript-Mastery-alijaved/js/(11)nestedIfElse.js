// nested if else
// winning Number 19
// 19 number guess right
// 17 number guess is low
// 20 number guess is high

let winningNumber=20
let userGuess=+prompt("user guess a number")
console.log("userGuess",typeof userGuess)
let answer=userGuess===winningNumber?"your guess is right !!!":"your guess is wrong !!!"
if(userGuess===winningNumber){
    console.log("your guess is right")
}else{
    if(userGuess>winningNumber){
        console.log("your guess is high")
    }else{
        console.log("your guess is low")
       
    }
}
console.log("answer",answer)

let temperature=15;
if (temperature<5){
    console.log("is very good")
}
 else if(temperature<10){
    console.log("it is very exellent")
}
else if(temperature<15){
    console.log("it is very very exellent")
}
else if(temperature<20){
    console.log("it is very very short")
}
else{
    console.log("it is marvallus")
}

