// spread operator
const array1 = [1, 2, 3]
const array2 = [4, 5, 6]
// diffrence between normal behavior
const newArray = [array1, array2]
console.log("newArray", newArray);
// diffrence between normal behavior and spreed operator
const newArrays = [...array1, ...array2]
console.log("newArrays", newArrays);

// spreed operator in objects

// we can use keys only one time on javascript in object and some reson we can use multiple time one key we can owerwrite second of one key.

// for example

obj1 = {
    Key6: "value1",
    Key2: "value2",
    Key3: "value3",
}
obj2 = {
    Key4: "value4",
    Key5: "value5",
    Key6: "value6",
}
const newObjt = { ...obj2, ...obj1 }
const newObjts = { ...obj1, ...obj2 }
const NewObjts = { ...obj1, ...obj2, Key7: "value7" }


console.log("newObjt", newObjt);
console.log("newObjts", newObjts);
console.log("NewObjts", NewObjts);

// we can use spreed operator on object using array
const newObjects = { ...["item1", "item2"] }
console.log("newObjects", newObjects)
const abcd = { ..."abcdefghijklmnopqrstuvwxyz" }
console.log("abcd", abcd)