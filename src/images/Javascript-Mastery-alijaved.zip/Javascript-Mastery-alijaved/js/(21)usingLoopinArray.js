// using Loop Array
let fruits=["apple","mango","banana","graps","pineapple","cherry"];
let fruits2=[]
console.log("fruits lenght",fruits.length)
console.log("fruits lenght",fruits[fruits.length-1])

for(let i=0;i<fruits.length;i++){
    console.log(fruits[i].toUpperCase())
    fruits2.push(fruits[i].toLowerCase())

}
console.log("fruits2",fruits2)
console.log("after pushing array 2 use loop")
for(let e=0;e<fruits2.length;e++){
    console.log("fruits2",fruits2[e])
    // fruits2.push(fruits[i].toLowerCase())

}