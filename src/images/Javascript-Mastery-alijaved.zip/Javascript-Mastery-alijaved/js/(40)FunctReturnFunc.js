// function returning function
function myFunc(){
   return function hello(){
        return "hello world";
    }
    }
const ans= myFunc()
console.error(ans())