// fill method
// value startIndex endIndex  
const newarr = new Array(10).fill(1)
console.log("fill", newarr)

const arry = [1, 2, 3, 4, 5, 6, 7, 8, 9]
const arrays = [1, 2, 3, 4, 5, 6, 7, 8, 9]

const Fill = arrays.fill(0, 2, 5)
console.log("fill", Fill)
// fill method