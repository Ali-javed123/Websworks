//  basically humare javascript me array kuch ase bunta h
let number =new  Array (1,2,2,3,3,4,5,6,7,8)
console.log(number)
console.log(Object.getPrototypeOf(number))
let numbers=[1,2,3,4,5,6,7,8,9]
console.log(numbers)
console.log(Object.getPrototypeOf(numbers));
console.log(Array.prototype)