// splice method
// start , delete , insert 

const myArray = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6'];
let arrys = myArray.splice(1, 2, "item8", "item9")
console.log("splice", myArray)
console.log("splice", arrys)
// splice method
