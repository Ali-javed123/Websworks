const number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


// reduce method
const sum = number.reduce((accumulater, currentvalue) => {
    return accumulater + currentvalue
}, 100)
console.log("reduce ", sum)
// reduce diagram
// accumulator currentvalue reuturn
//   1           2        3
//   3           3        6
//   6           4       10
//   10          5       15
//   15          6       21
//   21          7       28
//   28          8       36
//   36          9       45
//   45          10      55
// reduce diagram
userCart = [
    { userID: 1, category: "laptop", price: 1000 },
    { userID: 2, category: "mobile", price: 1000 },
    { userID: 3, category: "tv", price: 1000 },
    { userID: 4, category: "lcd", price: 1000 },
]
const totalsum = userCart.reduce((totalPrice, currentvalue) => {
    return totalPrice + currentvalue.price
}, 0)
console.log("reduce price", totalsum)


// totalprice   currentvalue       return
//  0                1000            1000
// 1000             1000             2000
// 2000             1000             3000
// 3000             1000             4000

// reduce method