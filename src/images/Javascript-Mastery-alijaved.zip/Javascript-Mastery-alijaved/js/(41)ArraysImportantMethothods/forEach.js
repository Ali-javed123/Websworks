const number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
function myFunc(number, index) {
    console.log(`the value of number is ${number} the value of index is ${index}`)
    console.log(`the value of number is ${number * 2} `)

}
for (let i = 0; i < number.length; i++) {
    myFunc(number[i], i);
}



// for each
// number.forEach(myFunc)

// annonyams functions
number.forEach(function (number, index) {
    console.log(`the value of number is ${number} the value of index is ${index}`)
    console.log(`the value of number is ${number * 2} `)
})
console.log("......")
const user = [
    { firstName: "ALi", Age: "20", Gender: "male", },
    { firstName: "Ibrahim", Age: "12", Gender: "male", },
    { firstName: "Adil", Age: "18", Gender: "male", }
]
user.forEach(function ({ firstName, Age, Gender }) {
    console.log(`FirstName: ${firstName}, Age :${Age}, Gender: ${Gender}`)
    // console.log(`the value of number is ${number*2} `)
})
// for each
