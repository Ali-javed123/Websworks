// map method
// method 1
const number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

const SqureRoot = []
const Squre = (Number) => {
    SqureRoot.push(Number * Number)
    console.log("SqureRoot", SqureRoot)
    return Number * Number
}

const SqureNumber = number.map(Squre)
console.log("SqureNumber", SqureNumber)
// method 1

// method 2
const SqureRoots = []
const SqureNumbers = number.map((Squre, index) => {
    SqureRoots.unshift(`${index}: ${Squre * Squre}`)
    console.log("SqureRoots", SqureRoots)
    return Squre * Squre

})
console.log("SqureNumbers", SqureNumbers)
// method 2

// real world example
const UserName = user.map((e) => {
    return e?.firstName
})
console.log("map", UserName)
// map method