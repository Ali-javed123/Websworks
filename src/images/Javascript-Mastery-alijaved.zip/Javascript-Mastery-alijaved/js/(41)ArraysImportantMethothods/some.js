// ever method
// hamare array me sab method 6000 se kam h
product = [
    { userID: 1, category: "laptop", price: 2200 },
    { userID: 3, category: "mobile", price: 1400 },
    { userID: 4, category: "tv", price: 3400 },
    { userID: 6, category: "lcd", price: 4500 },
    { userID: 5, category: "lcd", price: 5600 },
    { userID: 2, category: "lcd", price: 6200 },
]

// hamare array me koi bhi method 6000 se kam h
// some method
const answers = product.some((a => a.price < 6800))
console.log("some", answers)
// some method