
const number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


// filter function
const evenNumber = number.filter((num) => {
    return num % 2 !== 0
})
console.log("f  ilter out oddNumber", evenNumber)
// filter method