// iterables
// jispe hum for of loop laga sakein
// string , array are iterable 
// but object is not iteratble
let Names = "aliJaved"
const myArray = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6'];

for (let char of myArray) {
    console.log(char)
}