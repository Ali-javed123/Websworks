product = [
    { userID: 1, category: "laptop", price: 2200 },
    { userID: 3, category: "mobile", price: 1400 },
    { userID: 4, category: "tv", price: 3400 },
    { userID: 6, category: "lcd", price: 4500 },
    { userID: 5, category: "lcd", price: 5600 },
    { userID: 2, category: "lcd", price: 6200 },
]

// find method
const find = product.find((a => a.userID === 3))
console.log("find", find)
const Find = product.find((a => a.price > 3000))
console.log("price find", Find)
// find method