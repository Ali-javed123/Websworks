// Laxical Scope
function App(){
    const myVar="value1";
    const myFunc=()=>{
        const myFunc2=()=>{
            const myVar="value59";
            console.log("inside Func",myVar)
        }
        myFunc2()
    }
    console.log(myVar)
    myFunc()

}
App();