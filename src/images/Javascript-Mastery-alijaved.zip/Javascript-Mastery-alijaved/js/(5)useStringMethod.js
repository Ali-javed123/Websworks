// trim()
// toUpperCase()
// toLowerCase()
// slice


// trim method
let firstNames="  aliJaved  "
console.log("firstName.length",firstNames.length)
firstNames=firstNames.trim()
console.log("firstName.length",firstNames.length)
// trim method

// toUpperCase()
firstNames=firstNames.toUpperCase()
console.log("firstname",firstNames)

// toUpperCase()

// toLowerCase()
firstNames=firstNames.toLowerCase()
console.log("firstname",firstNames)

// toLowerCase()


// slice method

// start index
// end index

let newString=firstNames.slice(0,3)
console.log("newstring",newString)

// slice method
