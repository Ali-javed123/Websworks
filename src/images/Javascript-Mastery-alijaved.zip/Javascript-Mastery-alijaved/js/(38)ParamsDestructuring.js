// param destructuring
// object
// react

const person={
    firstName:"ali",
    age:"22",
    gender:"male"
}
 
function Detail({firstName,gender,age}){
    console.log("firstName",firstName)
    console.log("gender",gender)
    console.log("age",age)


}
Detail(person)