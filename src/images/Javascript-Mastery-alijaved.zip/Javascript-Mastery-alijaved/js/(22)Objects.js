// objects are refrence type
// arrays are good but not sufficient for real world data
// objects store key value pairs
// objects do not have index
// how to create objects
const person={
    name:"ali",
    age:22,
    hobbies:["pray","sleeping","learning"]
}


// hot to access data from objects
console.log(person);
console.log(person.age);
console.log(person["age"]);
console.log(person.name);
console.log(person["name"]);

console.log(person.hobbies);
// how to add key value pair to objects
person.gender="male";
console.log(person);
person["fruit"]="banana";
console.log(person);


