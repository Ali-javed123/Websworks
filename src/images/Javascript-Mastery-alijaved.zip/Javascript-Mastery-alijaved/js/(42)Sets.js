// Sets (it is iterable)
// store data  
// sets also have its own methods
// No index-based access 
// Order is not guaranteed
// unique items only (no duplicates allowed)


const Numbers = new Set()
const items = ['item1', 'item2', 'item3'];
console.log(Numbers)
Numbers.add("item1")
Numbers.add(1)
Numbers.add(2)
Numbers.add(3)
Numbers.add(4)
Numbers.add(5)
Numbers.add(6)
Numbers.add(7)
Numbers.add(8)
Numbers.add(9)
Numbers.add(10)



Numbers.add("item2")
// agar array variable me save krke dublicate array values push krte hein to invalid h
Numbers.add(items)
// invalid
// Numbers.add(items)
// invalid

// valid 
// agar dublicate array without variable me save kre squre bracket me save krte hein to valid h
Numbers.add(['item1', 'item2', 'item3'])
Numbers.add(['item1', 'item2', 'item3'])
// valid 
console.log(Numbers)

// set check method
if (Numbers.has("item1")) {
    console.log("Item is present")
} else {
    console.log("Item is not present")
}

for (let checks of Numbers) {
    console.log("loop", checks)
}
const myArray = [1, 2, 3, 4, 5, 6, 7, 2, 4, 5]
const uniqueVal = new Set(myArray)
console.log("uniqueVal", uniqueVal)
// check uniqueVal set lenght
let lenght = 0;
for (let val of uniqueVal) {
    lenght++
}
console.log("lenght", lenght)






