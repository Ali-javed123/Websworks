// object destructuring
const band={
    bandName:"led zepplin",
    famousSong:"stairway to heaven",
    year:1997,
    anotherFamousSong:"kashier"
}
// using variable
const bandNames=band.bandName;
const famousSongs=band.famousSong;
console.log("bandName",bandNames)
console.log("famousSong",famousSongs)
// using variable


console.log("--------")
// using destructuring
console.log("bandss",band)
// first type
const {bandName,famousSong}=band;
console.log("bandName2",bandName)
console.log("famousSong2",famousSong)

// second type object destructure using object key in variable
console.log("object destructuring seond type")

const {bandName:var1,famousSong:var2, ...restprops}=band;
console.log("var1",var1)
console.log("var2",var2)
console.log("restprops",restprops)



// using destructuring

