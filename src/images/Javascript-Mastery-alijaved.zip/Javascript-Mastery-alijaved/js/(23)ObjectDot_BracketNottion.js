// diffrence between dot and bracket notation
// agar key me space dena h to string use kro otherwise error ayega
const key="email";
const number="Number";
const person={
    name:"ali",
    age:22,
    "person hobbies":["pray","sleeping","learning"]
}
// how to access brcket notation on object 
console.log("person",person)
console.log("person hobbies",person["person hobbies"])

// how to add brcket notation on object from variable
// bracket notation aap key ke value nikal sakte hein
person[key]="ali@gmail.com"
person[number]=+"031339873423";

console.log("person",typeof person.Number)
console.log("person", person)

