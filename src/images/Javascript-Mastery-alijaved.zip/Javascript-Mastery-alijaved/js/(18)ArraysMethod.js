// arrays method
// arrays push 
// arrays pop 
// arrays shift 
// arrays unshift 

let fruits=["apple","mango","banana"];
console.log("fruits",fruits)

// push()
// arrays push add last index
fruits.push("Pineapple")
console.log("fruits",fruits)

// pop()
// arrays push remove last index and return your item
// fruits.pop()
let poppedFruits=fruits.pop()

console.log("fruits",fruits)
console.log("popped fruits is",poppedFruits)
console.log("fruits",fruits)

// unshift
// unshift add start index element on arrays
fruits.unshift("cherry")
fruits.unshift("blueberry")

console.log("fruits",fruits)

// shift
// shift remove start index element on arrays
let shiftFruits=fruits.shift()

console.log("the shift fruit is",shiftFruits)
console.log("fruits",fruits)

// push() pop() fast as compare to shift() and unshift()
// push() pop() fast
// shift() and unshift() slow