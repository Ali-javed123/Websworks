// ternery operator
//  let age=9;
//  let drink;

//  if (age>10){
//     drink="milk"
//  }else{
//     drink="coffee"
//  }
//  console.log("drink",drink)

let age=17
let drink;
drink=age>=18?"milk":"coffee";
console.log("drink",drink)

// and or operator
let firstName="Ali";
if(firstName[0]==="A" && age>18){
    console.log("inside if")
}else{
    console.log("inside else")
}

if(firstName[0]==="A" || age>18){
    console.log("inside if")
}else{
    console.log("inside else")
}