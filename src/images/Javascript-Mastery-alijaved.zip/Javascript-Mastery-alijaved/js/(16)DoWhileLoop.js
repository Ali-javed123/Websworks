let i=0;
do{
    console.log("the value of i is",i)
    i++
}while(i<=10)
console.log("do while loop block end value of i is",i)
