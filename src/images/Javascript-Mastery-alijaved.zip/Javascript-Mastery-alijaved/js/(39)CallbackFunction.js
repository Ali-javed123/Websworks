// callback functions

function myFunc2(name) {
    console.log("inside my func 2")
    console.log(`my name is ${name}`)
}
function myFunc1(callback) {
    console.log("hello func1")
    callback("ali")

}
myFunc1(myFunc2)