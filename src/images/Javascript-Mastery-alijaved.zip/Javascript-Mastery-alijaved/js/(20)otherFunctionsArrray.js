// how to clone array
// how to cancatenate two arrays
let array1=["item1","item2","item3"]
let array2=array1
console.log(array1)
console.log(array2)
console.log(array1===array2)
array1.push("item4")
console.log(array1)
console.log(array2)
console.log(array1===array2)

let array3=["item1","item2","item3"]
let array4=["item1","item2","item3"]
console.log(array4)
console.log(array3)
console.log(array4===array3)
array3.push("item4")
console.log(array3)
console.log(array4)
console.log(array4===array3)

// clonning of array
let array5=["item1","item2","item3"]
// clone array method

// method 1
// console.log("after array5 slice method clone to array 6 and concat some item 6")
// array6=array5.slice(0).concat(["item6","item7"]);
// console.log("array5",array5)
// console.log("array6",array6)
// method 2
// let array6=[].concat(array5);
// console.log("array5",array5)
// console.log("array6",array6)

// method 3 new method
// spread operater
let array6=[...array5,"item4","item5","item6"];
let oneMoreArray=["item4","item5","item6"]
let array7=[...array5,...oneMoreArray];

console.log("array5",array5)
console.log("array6",array6 )
console.log("array7",array7 )


console.log(array4===array3)
// array5.push("item4")
// console.log("array5",array5)
// console.log("array6",array6)


