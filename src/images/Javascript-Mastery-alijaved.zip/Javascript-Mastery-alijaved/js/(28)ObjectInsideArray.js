// object inside arrays
// vaer useful in real world application
const users=[
    {userId:1,firstName:"ali",gender:"male"},
    {userId:2,firstName:"adil",gender:"male"},
    {userId:3,firstName:"ibrahim",gender:"male"}
]
for(let user of users){
    console.log("user loop",user)
    console.log(user.firstName)
    console.log(user.userId)
    console.log(user.gender)
}