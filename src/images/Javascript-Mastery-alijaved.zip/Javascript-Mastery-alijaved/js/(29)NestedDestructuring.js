// Nested Destructuring
const users=[
    {userId:1,firstName:"ali",gender:"male"},
    {userId:2,firstName:"adil",gender:"male"},
    {userId:3,firstName:"ibrahim",gender:"female"}
]
const [{firstName:usersfirst,userId:ID}, ,{gender:Gender}]=users
console.log(usersfirst,"..",ID,"..",Gender)