///
const create = {
    firstName: "ali",
    address: { houseNumber: '2222' }
}
console.log("create", create?.address?.houseNumber)

