// clone using object.assign
// using

const user1 = {
    key1: "ali",
    key2: "ali"
}
// agar aap is tareke se new object ko porana ka refrence dedete he hein to wo jo chiz porana me add hoge wo new me bhi add ge 
const obj2 = user1;
console.log("obj2", obj2)
user1.key3 = "alijaved"
console.log("obj2", user1)

// first method
// agar aap is tareke se new object ko porana object se clone krte hein jo chiz porana me add wo new me add nahe nahe hoge
// first method
const user2 = { ...user1 }

// second method
const user3 = Object.assign({}, user1)
console.log("user2", user3)

user1.key3 = "ali";
console.log("user2", user2)
console.log("user1", user1)

