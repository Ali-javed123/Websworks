function createUser(firstName, lastName, Number, Age) {
    this.firstName = firstName
    this.lastName = lastName
    this.Number = Number
    this.age = Age



   
}
const user1=new createUser("hello","kumat",20000,33)
console.log(user1)

// 1# new keyword create empty object {}
// 2# add this and return this object
// 3# new keyword chain create krta h