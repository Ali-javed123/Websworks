// array destracturing

// first method
let Fruits=["apple","mango","banana","graps","cherry","blueberry"]
let [Fruits2,Fruits3]=Fruits
console.log("value of Fruit2 is",Fruits2)
console.log("value of Fruit3 is",Fruits3)
// first method

// second method
let item =["item1","item2","item3","item4",]
let [item1, ,item2]=item
console.log("value of item1 is",item1)
console.log("value of item2 is",item2)
// second method

// third method
let number=[1,2,3,4]
let newNumber=number.slice(2)
console.log("value of newNumber is",newNumber)
// third method

// fourth method
let fruits=["apple","mango","banana","graps","cherry","blueberry"];
let [fruits2,fruits3, ...myNewArrays]=fruits
console.log("value of fruit2 is",fruits2)
console.log("value of fruit3 is",fruits3)
console.log("value of myNewArrays is",myNewArrays)
// fourth method

// fifth method
let newItem=["apple","mango","banana","graps","cherry","blueberry"];
let {length, [length - 1]: last }=newItem
console.log("value of fruit2 is",fruits2)
console.log("value of fruit3 is",fruits3)
console.log("value of fruit3 is",last)
// fifth method




