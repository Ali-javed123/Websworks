// declear variable with let keyword;
let firstName = "Ali";
firstName = "aliJaved";
console.log("firstName", firstName);
// string indexing
// A l i j a v e d
// 0 1 2 3 4 5 6 7

// last index:lenght -1
console.log("firstnames",firstName[0])
// print index
console.log(firstName.length)
// print last index
console.log("firstname lenght last character",firstName[firstName.length-1])