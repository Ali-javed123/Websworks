// how to iterate object
const person={
    name:"ali",
    age:22,
    "person hobbies":["pray","sleeping","learning"]
}
// for in loop
// Object key

for(let key in person){
   console.log(`${key}:${person[key]}`)
   console.log("breaks")
   console.log(key,":",person[key])

    // console.log("Person key value",person[key])
}
console.log("--------")

console.log(typeof (Object.keys(person)))
const val=Array.isArray((Object.keys(person)))
const val3=Object.keys(person)
console.log("val3",val3)

console.log("val",val)
console.log("--------")
// Object key 
// for of loop
for(let key of Object.keys(person)){
   console.log(`${key}:${person[key]}`)
   console.log(key,":",person[key])


}

