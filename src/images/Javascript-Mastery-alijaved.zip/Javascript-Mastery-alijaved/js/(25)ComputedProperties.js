//  computed properties
const key1="object1";
const key2="object2";

const value1="myValue1";
const value2=",myValue2";
const obj={};
console.log("obj",obj)

obj[key1]=value1;
obj[key2]=value2;
console.log("obj",obj)
