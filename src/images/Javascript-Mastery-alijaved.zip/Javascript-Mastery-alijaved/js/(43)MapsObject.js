// Maps
// map is an iterable

// store data in ordered fashion

// store key value pair (like object)
// duplicate keys are not allowed like objects


// different between maps and objects

// objects can only have string or symbol
// as key 

// in maps you can use anything as key
// like array, number, string 

// object literal 
// key -> 99% string  
// key -> 1% symbol

// map store key value pair
const Number = "number"

//  matlab jo hum khud se object banaye
// this is object syntex is called by object leteral
const person = {
    firstName: "harshit",
    age: 7,
    1: "one"
}
// this is object syntex is called by object leteral
//  matlab jo hum khud se object banaye

// sab se bara defrence map/object me ye ke is key kise bhi ke rakh sathte hein chahe wo number string ho symble ho object literal ho ,array ho  .. 
console.log(typeof person.firstName, person.firstName)
console.log(typeof person[1], person[1])
person[Number] = +"03133987342"
console.log(person)
console.log(typeof person.number, person[Number])

const persons = new Map()
persons.set("Name", "Ali")
persons.set("Number", +"03133987342")
persons.set("Age", "20")

// print scecific key
console.log("persons", persons.get("Number"))

// print map key
console.log("persons", persons.keys())


// for of loop map key
for (let key of persons.keys()) {
    console.log(key)
}
for (let [key, values] of persons) {
    console.log("Person", typeof key, values, key, values)
}

// for of loop map key
// map real world example
const personInFo = {
    firstName: "harshit",
    id: 7,
}

const personInFo2 = {
    firstName: "ali",
    id: 17,
}
const extraInFo = new Map()

extraInFo.set(personInFo, { gender: 11, age: 20 })
extraInFo.set(personInFo2, { gender: 12, age: 22 })


console.log("personInFo2", personInFo2)
console.log("userInFo", extraInFo.get(personInFo2).gender)
