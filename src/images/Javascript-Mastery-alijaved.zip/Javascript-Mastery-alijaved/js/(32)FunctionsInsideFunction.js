// function inside functions
function app(){
    const myfunc=()=>{
        console.log("hello")
    }
    const numTwoNumbers=(c,d)=>c*d
    const numTwoNumber=(a,b)=>a*b
    console.log(numTwoNumber(2,2))
    console.log(numTwoNumbers(2,4))


}
app()