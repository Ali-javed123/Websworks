// function 
// run invoke call one word
function singHappyBirthday() {
    console.log("happy birth day")
}
function sumThreeNumber(number1, number2, number3) {
    return number1 + number2 + number3;
}
const returnValue = sumThreeNumber(1, 2, 3)
console.log(returnValue)

// isEven 
// output:1 number
// output:true,false

function isEven(number) {
    return number % 2 === 0
}
console.log(isEven(54))

function firstChar(anyString) {
    return anyString[0]
}
console.log(firstChar("cebz"))

// function expression
const findTraget = function (array, target) {
    for (let i = 0; i < array.length; i++) {
        console.log("i", i)
        if (array[i] === target) {
            return i
            console.log("i", i)
        }
    }
    return -1;
}
// function expression

const myArray = [1, 3, 8, 90]

const ans = findTraget(myArray, 3)


console.log("a", ans)