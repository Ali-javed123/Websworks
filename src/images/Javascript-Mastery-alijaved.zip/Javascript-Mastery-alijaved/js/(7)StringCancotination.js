let String1="10";
let String2="20";
newString=+String1 + +String2;
console.log(newString)