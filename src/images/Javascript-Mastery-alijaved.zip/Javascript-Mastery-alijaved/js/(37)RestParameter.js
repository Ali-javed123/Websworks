// Rest Parameter
function myfunc(a,b,c,...d){
    console.log(`a is ${a}`)
    console.log(`b is ${b}`)
    console.log(`c is ${c}`)
    console.log(`d is ${d}`)
}
myfunc(1,2,3,4,5,6)

function All(...numbers){
    let total=0
    for(let number of numbers){
        total=total+number;
        console.log(total)
    }
    return total;
}
let ans=All(1,2,3,4,5,6,7,8,9)
console.log("ans",ans)