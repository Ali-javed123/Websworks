// static method and properties
class Person{
    constructor(name,age){
        this.name=name,
        this.age=age
    }
    static  classinFo(){
        return  `this person is static`
    }
    static  des="ss"
    get fullname(){
        return `${this.name} ${this.age}`
    }
    set fullname(name){
        const [firstname,lastname]=this.name.split(" ");
        this.firstname=firstname;
        this.lastname=lastname;
    }


}
const Personss= new Person("ali",12)
//  ye galti nahe karna static fun direc console nahe le sakte
const info=Person.classinFo()
console.log(info)
console.log(Personss.des)