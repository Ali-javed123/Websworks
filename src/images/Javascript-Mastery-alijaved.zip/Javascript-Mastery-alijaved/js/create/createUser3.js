
const UserMethod = {
    about: function () {
        return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`
    },
    is18: function () {
        return this.age > 18
    },
    sing:function(){
        return "ddfdsfsdsd";
    }
}
function createUser(firstName, lastName, Number, Age) {
    const user = Object.create(UserMethod)
    user.firstName = firstName
    user.lastName = lastName
    user.Number = Number
    user.age = Age



    return user;
}
const users1 = createUser("Ali", "javed", '03133387344', 19)
const users2 = createUser("kamran", "jawed", '03133287346', 19)
const users3 = createUser("shoaib", "jawad", '03133287343', 19)

console.log(users1.sing())
// ab sab kab sahi h q k humne fiction ka refrence diya h h but agar but 1000 methid banane hoye to pahle humein UserMethod me 100 method banane pare ge pher createUser me is ka refrence dena pare ga aur hum kisi method ka refrence dena bhol gaye to  