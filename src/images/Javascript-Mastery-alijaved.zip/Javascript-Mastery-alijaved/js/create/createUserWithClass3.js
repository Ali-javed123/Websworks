// super keyword
class Animal{
    constructor(name,age){
        this.name=name
        this.age=age
    }
    eat(){
        return `${this.name} ${this.age} is eat`
    }
    isSuperCute(){
        return this.age<2
    }
    isCute(){
        return true
    }
} 
const animal=new Animal("tommy",19)
console.log(animal)

class Dog extends Animal{
    constructor(name,age,speed){
        super(name,age);
        this.speed=speed
    
        }
        eat(){
        return `Modify Eat:${this.name} is eating`
        }
    run(){
        return `${this.name} is running at ${this.speed} is kpmh`
    }
}
const Dogs=new Dog("tommy",19,29)
console.log(Dogs.eat())
// object/intance same cheez