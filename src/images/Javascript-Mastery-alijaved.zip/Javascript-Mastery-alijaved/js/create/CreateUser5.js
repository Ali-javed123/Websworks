
// 2015 /es6
// class keywords
// class are fake
// class ke ander jo function ho hein unko method bolte hein
class CreateUsers{
    constructor(firstName, lastName, Number, Age){
        console.log("constructor called")
        this.firstName = firstName
        this.lastName = lastName
        this.Number = Number
        this.age = Age
    }
    
    about(){
    return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`

    }
    is18(){
        return this.age > 18

    }
    is18(){
    return "ddfdsfsdsd";

    }
}



function CreateUser(firstName, lastName, Number, Age) {
    this.firstName = firstName
    this.lastName = lastName
    this.Number = Number
    this.age = Age
}
CreateUser.prototype.about= function () {
    return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`
}
CreateUser.prototype.is18= function () {
    return this.age > 18
}
CreateUser.prototype.sing=function(){
    return "ddfdsfsdsd";
}
// jab bhi contructure function banate hein to function capital se start krte hein
const users1 =new CreateUser("Ali", "javed", '03133387344', 19)
const users4 =new CreateUsers("sohail", "javed", '03133387344', 19)

const users2 =new CreateUser("kamran", "jawed", '03133287346', 19)
const users3 =new CreateUser("shoaib", "jawad", '03133287343', 19)

console.log(users1)
// ab sab kab sahi h q k humne fiction ka refrence diya h h but agar but 1000 methid banane hoye to pahle humein UserMethod me 100 method banane pare ge pher createUser me is ka refrence dena pare ga aur hum kisi method ka refrence dena bhol gaye to  

// javascript me function to hein per function ko hum object ke trahan bhi treet kar sakte hein
// javascript function ===>function+object

    function hello(){
        console.log("hello");
    } 
console.log("functiom name",hello.name)
hello.veryOwnProperty="unique";
console.log(hello.veryOwnProperty)
// you can add your own property
// aap apne khud ke bhi property add kr sakte ho
// funtion provide more  useful property
// funtion provide free space===>prototype
// only funtion provide provide property

if(hello.prototype){
    console.log("prototype is present")
}else{
    console.log("prototype is not present")
}

// is __proto__   of official ecmascript ne [[prototype]]
// agar aap firefox me dekho de to __proto__ likaha aye ga
// aur chrome me [[prototype]] likha aye ga

for(let user in users1){
    if(users1.hasOwnProperty(user)){
        console.log(user);
    }
}

let number=[18459]
console.log(number)
// jab jab humne console.log kiya to is me prototype a rahe hein  jab k ye to function nahe hein 
// interneraly javacript aye se 
const myArray = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6'];

let numbers=myArray
hello.prototype=[]
hello.prototype.push("1")
console.log(hello.prototype)