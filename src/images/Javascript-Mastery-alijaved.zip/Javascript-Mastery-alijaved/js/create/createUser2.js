
const UserMethod = {
    about: function () {
        return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`
    },
    is18: function () {
        return this.age > 18
    }
}
function createUser(firstName, lastName, Number, Age) {
    const user = {}
    user.firstName = firstName
    user.lastName = lastName
    user.Number = Number
    user.age = Age
    user.about = UserMethod.about
    user.is18 = UserMethod.is18


    return user;
}
const users1 = createUser("Ali", "javed", '03133387344', 19)
const users2 = createUser("kamran", "jawed", '03133287346', 19)
const users3 = createUser("shoaib", "jawad", '03133287343', 19)

console.log(users1.about())