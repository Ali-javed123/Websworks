// getter setters

class Person{
    constructor(name,age){
        this.name=name,
        this.age=age
    }
    get fullname(){
        return `${this.name} ${this.age}`
    }
    set fullname(name){
        const [firstname,lastname]=this.name.split(" ");
        this.firstname=firstname;
        this.lastname=lastname;
    }


}
const person =new Person("Ali",12)
console.log(person.fullname)
Person.fullname="ALi Javed"
console.log(person.fullname)
