
// 2015 /es6
// class keywords
// class are fake
// class ke ander jo function ho hein unko method bolte hein
class CreateUsers{
    constructor(firstName, lastName, Number, Age){
        console.log("constructor called")
        this.firstName = firstName
        this.lastName = lastName
        this.Number = Number
        this.age = Age
    }
    
    about(){
    return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`

    }
    is18(){
        return this.age > 18

    }
    is18(){
    return "ddfdsfsdsd";

    }
    sing(){
        return "la la la la la la la la la"
    }
}
// aap ko humesha new keyword laga k he call karne h
const users4 =new CreateUsers("sohail", "javed", '03133387344', 19)
console.log(users4)
console.log(Object.getPrototypeOf( users4))

