const user1 = {
    firstName: "Ali",
    lastName: "Javed",
    Number: "03133987342",
    age: "male",
    about() {
        return `${this.firstName + this.lastName} ${this.age} ${this.Number}`
    },
    is18() {
        return this.age > 18
    }

}

function createUser(firstName, lastName, Number, Age) {
    const user = {}
    user.firstName = firstName
    user.lastName = lastName
    user.Number = Number
    user.age = Age
    user.about = function () {
        return `userName is ${this.firstName + this.lastName},user age is ${this.age},user number is ${this.Number}`
    }
    
    user.is18 = function () {
        return this.age > 18
    }

    return user;
}
const users = createUser("Ali", "javed", '03133987342', 19)
console.log(users.about())
//  is function me me koi kamia h matlab jitne bar humara object create hoga to atni bar humara function banege