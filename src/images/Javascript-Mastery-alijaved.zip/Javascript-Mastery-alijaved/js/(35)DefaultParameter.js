// Default Parameture
// 2016 se pahle aysa hota tha
// function sum(a,b){
//     if(typeof b==="undefined"){
//         b=0

//     }
//     return a+b;
// }
function sum(a,b=1){
    return a+b;
}
const ans=sum(4)
console.log("ans",ans)
