// function 
// run invoke call one word
function singHappyBirthday(){
    console.log("happy birth day")
}
function sumThreeNumber(number1,number2,number3){
return number1+number2+number3;
}
const returnValue=sumThreeNumber(1,2,3)
    console.log(returnValue)

// isEven 
// output:1 number
// output:true,false

// agar 1 parameter hoto bracket hata sakte hein otherwise nahe
const isEven=number=>number%2===0

// agar 1 parameter hoto bracket hata sakte hein otherwise nahe

console.log("isEven",isEven(54))

const firstChar=(anyString)=>anyString[0]

console.log("firstChar",firstChar("ali"))

// function expression
const findTraget =function(array,target){
    for(let i=0;i<array.length;i++){
        console.log("i",i)
        if(array[i]===target){
            return i
        }
    }
    return -1;
}
// function expression

const myArray= [1,3,8,90]

const ans=findTraget(myArray,3)


console.log("a",ans)

const check=(array,Target)=>{
    for(let i=0;i<array.length;i++){
        console.log("i",i)
        if(array[i]==Target){
            return i
        }
    }
    -1
}
const myArrays=[1,2,3,4,5]
const ans1=check(myArrays,3)
console.log("ans",ans1)