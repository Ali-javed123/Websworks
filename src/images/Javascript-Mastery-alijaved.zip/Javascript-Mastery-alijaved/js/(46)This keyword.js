// this and window are same keyword
// this ===window ture
// window and this javscript globel object

console.log(this)
console.log(window)
function myfunc() {
    console.log("sdcsa")
}
console.log(window)
window.myfunc()

// agar use strick mode use kroge to undefined aye ga