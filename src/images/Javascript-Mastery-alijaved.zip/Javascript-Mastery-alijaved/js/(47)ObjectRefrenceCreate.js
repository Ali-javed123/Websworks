const obj1 = {
    key1: "value1",
    key2: "value2",

}
// is line se object2 ka refrence set object1 se ho gaya
const obj2 = Object.create(obj1)
// create se protro set hogaye yane chain crate hogaye/
// is line se object2 ka refrence set object1 se ho gaya
obj2.key3 = "value3"
console.log(obj2.key1)
//  ye is ke [prototype] me store hogya
// proto or[prototype] but prototype not same

