// boolean & comperisson operator
// truethy or falsy value
// flasy value
// 0 
// undefined
// false 
// null


// falsy values
let age=17;
if (age>18){
    console.log("user can play mario")
}else{
    console.log("user can play ddlc")
}

let num=11
if(num%2==0){
    console.log("even")
}else{
    console.log("odd")
}

console.log("falsy value")

let secondName=null;
if(secondName){
    console.log("firstName null",firstName)
}else{
    console.log("firstname is kind a empty");
}

let thirdName=undefined;
if(thirdName){
    console.log("firstName undefined",firstName)
}else{
    console.log("firstname is kind a empty");
}

let forthName="";
if(forthName){
    console.log("firstName empty string",firstName)
}else{
    console.log("firstname is kind a empty");
}

let fifthName=false;
if(fifthName){
    console.log("firstName false",firstName)
}else{
    console.log("firstname is kind a empty");
}

// truethy values
// true 
// 123
// abc
// 1,-1
console.log("truethy value")
let sixName=true;
if(fifthName){
    console.log("firstName false",firstName)
}else{
    console.log("firstname is kind a empty");
}

let sevenName=123;
if(sevenName){
    console.log("firstName false",secondName)
}else{
    console.log("firstname is kind a empty");
}

let eightName="abc";
if(eightName){
    console.log("firstName false",eightName)
}else{
    console.log("firstname is kind a empty");
}




