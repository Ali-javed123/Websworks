// primitive type
// all type of variable is primitive type
let num1=5;
let num2=num1;
console.log(`the value of num1 is ${num1}`)
console.log(`the value of num1 is ${num2}`)
num1++
console.log("after increament num1")
console.log(`the value of num1 is ${num1}`)
console.log(`the value of num1 is ${num2}`)
// all type of variable is primitive type

// refrence type
// all type of object is refrence type
let array1=["item1","item2"]
let array2=array1
console.log(`the value of array1 is ${array1}`)
console.log(`the value of array2 is ${array2}`)
array1.push("item3")
console.log("after pushing array1")
console.log(`the value of array1 is ${array1}`)
console.log(`the value of array2 is ${array2}`)
