// continue keyword
// break keyword

let i;
for(i=0;i<=10;i++){
    if(i===5){
        break;
        

    }
    console.log("",i)

}
console.log("hello break i" ,i)

let e;
for(e=10;e>=1;e--){
    if(e===5){
        continue;
        
    }
    console.log("e",e)
}
console.log("hello break i" ,e)