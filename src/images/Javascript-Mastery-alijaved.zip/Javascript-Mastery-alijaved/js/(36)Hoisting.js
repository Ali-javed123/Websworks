// hoisting

// invalid

// hello()
// const hello=()=>{
//     console.log("hello")
// }


// console.log(firstName)
// let firstName="ali"

// invalid

// valid

hello()
function hello(){
    console.log("hello")
}

console.log("firstName",firstName)
var firstName="ali";
firstName="ali"
console.log("firstName",firstName)

// valid
