// compilation 
// code execution

// how javascript code compile
// what is globle execution context?
// what is local execution context?
// closoures


// compilation 3 pahase ke hote h
// 1)Tokinizing/Lexing humara code chote chote chunks ke divide hogata h gis se batna 
// 2)Parsing un chunks ko use krke hum bate h AST 
// 3)AST ke help se hum asa executable Code Generation krte h
// compilation 3 pahase ke hote h
// ye tamama kam hone bad AST banta h,
// Ecma Script ke documentation ye kahe nahe lika k code compile krna h but ye likha h k Erraly Error Checking hone chahie aur ditarmining apropiate scope for variable DASV pata hone chahie
// jab javacript ka koi code kise function me hota to globle scope me hota h

// javascript Synchronous programing language h aur single single treed programing language h
// 1)aik creation face 
// 2)dosra hota h coda code execution face
// ab hoisting kia h code var banane se pahle he hamare memory me save hogaye aur is ke value undefined hogaye the

console.log(this)
console.log(window)
console.log(myfuc())
console.log(fullname)
function myfuc(){
    console.log("my fuc")
}

var firstname="ali"
var lastname="Javed"
var fullname= `${firstname} ${lastname}`


console.log(this)
console.log(window)
console.log(myfuc())
console.log(fullname)


// var k cas me

// undefined hoga

console.log(firstnames)

var firstnames="ali"

// let k case me
// uninitialize
// Uncaught ReferenceError: Cannot access 'lastnames' before initialization
// console.log(lastnames)
let lastnames="ali"
console.log(lastnames)


// const k case me
// uninitialize
// Uncaught ReferenceError: Cannot access 'lastnames' before initialization
// console.log(lastnamesd)
let lastnamesd="ali"
console.log(lastnamesd)

// let aur const dono ke hoisting h

// Uncaught ReferenceError: dsf is not defined
// ye alag error h ye jab koi variable banahe na ho to aap asko print kre
// console.log(dsf)
let dsf="asd"
// aur 1 aur bat jab ye dsf name ka variable Initilalize nahe hoja jab tak ye variable tamporale dad zone me rahe ga yane error deta rahe ga

// javascript ka kam 2 faces me hota h 
// 1)Compilaion face 
// 1)Code execution face 
// ab compilaion q hote h q k hum erarly checking kr saking aur DASV pata krna hota h
// is k bad hum code ko execute krna start karte h
// javascript code ko execute krne k liye execuion context  create krna prta h
// execuion context bhi do tarah k hote h 
// 1)creation creation face 
// 1)memory face 

// javscript me funcion execuion context h s
// is me bhi kam 2 faces me hota h 
// 1) Code Execuion face 
// 2)Memory creation face
// memory creation fcae me array like Object hota h
// jese fname 1 variable h to fname 1 parameter  aur fane is ke value hoge 

var fname="fane"


let foo="foo"
console.log(foo)
function getfullname(fname,lname){
    console.log
}








