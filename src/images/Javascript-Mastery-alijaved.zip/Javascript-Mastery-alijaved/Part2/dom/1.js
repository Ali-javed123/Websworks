// Dom
// Document Object model
// overview
// how to use
// deep study
console.log(window.document)
//  select element using get element by id
const mainHeader = document.getElementById("navbarNavAltMarkup")
console.log(mainHeader)


// select element using query selector  
const mainnHeading=document.querySelector('#navbarNavAltMarkup')
console.log(mainnHeading)

// change text
// textContent and innerText
 const mainnHeadings=document.getElementById('price')
 mainnHeadings.textContent="Price"
 