function printFullName(fname,lname){
    function printName(){
        console.log(fname,lname)
    }
    return printName
}
const ans=printFullName("ali","javed")
ans();

// is me fname printName ka fname aur fname closures h
function hello (x){
    const a= "var A"
    const b= "var A"
    return function(){
        console.log(a,b,x)
    }

}
const anss=hello("ali")
anss()


// const myfunc=power=>number=> number**power
const myfunc=(power)=>{
    return(number)=>{
        return number**power
    }
}
const squre=myfunc(2)
const  answ=squre(3)
console.log(answ)

// ..........

function func(){
    let counter = 0
    return function(){
        if(counter <1){
            console.log("Hi You called me")
            counter ++
        }else{
            console.log("hi me already aik bar call ho chuka hoon")
        }
    }
}
const myfuncs=func()
myfuncs()
myfuncs()